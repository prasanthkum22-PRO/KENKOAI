package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.navigation.JoniNavGraph
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.JoniViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        val viewModel: JoniViewModel = viewModel()
        JoniNavGraph(viewModel = viewModel)
      }
    }
  }
}
