package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface JoniDao {
  @Query("SELECT * FROM patients ORDER BY createdAt DESC")
  fun getAllPatients(): Flow<List<PatientEntity>>

  @Query("SELECT * FROM patients WHERE id = :patientId")
  suspend fun getPatientById(patientId: String): PatientEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPatient(patient: PatientEntity)

  @Query("SELECT * FROM assessments ORDER BY createdAt DESC")
  fun getAllAssessments(): Flow<List<AssessmentEntity>>

  @Query("SELECT * FROM assessments WHERE patientId = :patientId ORDER BY createdAt DESC")
  fun getAssessmentsForPatient(patientId: String): Flow<List<AssessmentEntity>>

  @Query("SELECT * FROM assessments WHERE id = :assessmentId")
  suspend fun getAssessmentById(assessmentId: String): AssessmentEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAssessment(assessment: AssessmentEntity)

  @Update
  suspend fun updateAssessment(assessment: AssessmentEntity)

  @Query("SELECT * FROM movement_assessments WHERE assessmentId = :assessmentId")
  suspend fun getMovementForAssessment(assessmentId: String): MovementEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMovement(movement: MovementEntity)

  @Query("SELECT * FROM ai_results WHERE assessmentId = :assessmentId")
  suspend fun getAiResultForAssessment(assessmentId: String): AiResultEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAiResult(aiResult: AiResultEntity)

  @Query("SELECT * FROM clinical_reviews WHERE assessmentId = :assessmentId")
  suspend fun getClinicalReview(assessmentId: String): ClinicalReviewEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertClinicalReview(review: ClinicalReviewEntity)

  @Query("SELECT * FROM referrals ORDER BY createdAt DESC")
  fun getAllReferrals(): Flow<List<ReferralEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertReferral(referral: ReferralEntity)

  @Query("SELECT * FROM sync_queue WHERE status = 'PENDING'")
  suspend fun getPendingSyncItems(): List<SyncQueueEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSyncQueue(item: SyncQueueEntity)

  @Query("UPDATE sync_queue SET status = 'SYNCED', syncedAt = :timestamp WHERE id = :id")
  suspend fun markSynced(id: String, timestamp: Long = System.currentTimeMillis())

  @Query("SELECT COUNT(*) FROM assessments")
  suspend fun getAssessmentCount(): Int

  @Query("SELECT COUNT(*) FROM assessments WHERE syncStatus = 'PENDING'")
  suspend fun getPendingSyncCount(): Int
}
