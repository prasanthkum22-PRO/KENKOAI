package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "patients")
data class PatientEntity(
  @PrimaryKey val id: String = UUID.randomUUID().toString(),
  val patientCode: String,
  val name: String,
  val age: Int,
  val sex: String,
  val location: String,
  val occupation: String,
  val contact: String,
  val consentStatus: Boolean,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "assessments")
data class AssessmentEntity(
  @PrimaryKey val id: String = UUID.randomUUID().toString(),
  val patientId: String,
  val workerId: String,
  val affectedJoint: String, // e.g. "Knee (Left)", "Knee (Right)", "Both Knees", "Hip", "Spine"
  val painScore: Int, // 0-10
  val painDuration: String, // e.g. "< 3 months", "3-6 months", "> 6 months"
  val stiffness: String, // e.g. "None", "Morning stiffness < 30m", "Morning stiffness > 30m"
  val swelling: Boolean,
  val mobilityLimitations: String, // e.g. "Walking difficulty", "Stair difficulty", "Sit-to-stand difficulty"
  val previousInjury: Boolean,
  val activityLevel: String, // e.g. "Sedentary", "Moderate", "Heavy physical labor"
  val status: String, // e.g. "COMPLETED", "DRAFT", "PENDING_REVIEW"
  val createdAt: Long = System.currentTimeMillis(),
  val syncStatus: String = "PENDING" // "PENDING", "SYNCED"
)

@Entity(tableName = "movement_assessments")
data class MovementEntity(
  @PrimaryKey val id: String = UUID.randomUUID().toString(),
  val assessmentId: String,
  val taskType: String, // e.g. "Walking & Sit-to-Stand"
  val duration: Int, // seconds
  val cadence: Float, // steps/min proxy
  val stepSymmetry: Float, // 0.0 - 1.0
  val movementRange: String, // e.g. "Moderate restriction"
  val kneeAngleFeatures: String, // e.g. "Asymmetrical flexion trajectory"
  val captureQuality: String, // e.g. "Good"
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ai_results")
data class AiResultEntity(
  @PrimaryKey val id: String = UUID.randomUUID().toString(),
  val assessmentId: String,
  val modelVersion: String = "OA-Screen-v0.1-demo",
  val priorityScore: Float, // 0.0 - 1.0
  val priorityCategory: String, // "Higher Review Priority" or "Routine Review"
  val confidence: Float, // e.g. 0.78
  val featureContributors: String, // comma-separated or json: "activity-related pain, mobility limitation, movement asymmetry"
  val explanation: String,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "clinical_reviews")
data class ClinicalReviewEntity(
  @PrimaryKey val id: String = UUID.randomUUID().toString(),
  val assessmentId: String,
  val clinicianId: String,
  val status: String, // "REVIEWED", "PENDING"
  val clinicalNote: String,
  val recommendation: String, // e.g. "Physiotherapy & Lifestyle Modification", "Orthopedic Specialist Referral"
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "referrals")
data class ReferralEntity(
  @PrimaryKey val id: String = UUID.randomUUID().toString(),
  val patientId: String,
  val assessmentId: String,
  val destination: String, // e.g. "District Hospital Physiotherapy Unit", "Community Health Center Orthopedics"
  val reason: String,
  val priority: String, // "High", "Medium", "Routine"
  val status: String, // "Active", "Completed", "Pending"
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
  @PrimaryKey val id: String = UUID.randomUUID().toString(),
  val deviceId: String = "JONI-FIELD-01",
  val recordType: String,
  val recordId: String,
  val operation: String, // "CREATE", "UPDATE"
  val status: String, // "PENDING", "SYNCED"
  val createdAt: Long = System.currentTimeMillis(),
  val syncedAt: Long? = null
)
