package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    PatientEntity::class,
    AssessmentEntity::class,
    MovementEntity::class,
    AiResultEntity::class,
    ClinicalReviewEntity::class,
    ReferralEntity::class,
    SyncQueueEntity::class
  ],
  version = 1,
  exportSchema = false
)
abstract class JoniDatabase : RoomDatabase() {
  abstract fun joniDao(): JoniDao

  companion object {
    @Volatile
    private var INSTANCE: JoniDatabase? = null

    fun getDatabase(context: Context): JoniDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          JoniDatabase::class.java,
          "joni_database"
        )
          .addCallback(JoniCallback())
          .build()
        INSTANCE = instance
        instance
      }
    }
  }

  private class JoniCallback : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
      super.onCreate(db)
      INSTANCE?.let { database ->
        CoroutineScope(Dispatchers.IO).launch {
          seedDemoData(database.joniDao())
        }
      }
    }

    suspend fun seedDemoData(dao: JoniDao) {
      val p1 = PatientEntity(
        id = "p-001",
        patientCode = "DEMO-001",
        name = "Lalsiem Hmingthana",
        age = 58,
        sex = "Male",
        location = "Aizawl Rural Sector 3",
        occupation = "Agricultural Worker",
        contact = "+91 98621XXXXX",
        consentStatus = true
      )
      val p2 = PatientEntity(
        id = "p-002",
        patientCode = "DEMO-002",
        name = "Vanlalruati",
        age = 63,
        sex = "Female",
        location = "Lunglei Hill Ward",
        occupation = "Handloom Weaver",
        contact = "+91 94361XXXXX",
        consentStatus = true
      )
      val p3 = PatientEntity(
        id = "p-003",
        patientCode = "DEMO-003",
        name = "Zoramthanga",
        age = 71,
        sex = "Male",
        location = "Champhai Border Village",
        occupation = "Retired Orchards Keeper",
        contact = "+91 97741XXXXX",
        consentStatus = true
      )
      val p4 = PatientEntity(
        id = "p-004",
        patientCode = "DEMO-004",
        name = "Rohlupuii",
        age = 52,
        sex = "Female",
        location = "Kolasib Outreach Camp",
        occupation = "Market Vendor",
        contact = "+91 96121XXXXX",
        consentStatus = true
      )
      val p5 = PatientEntity(
        id = "p-005",
        patientCode = "DEMO-005",
        name = "C. Lalrinsanga",
        age = 65,
        sex = "Male",
        location = "Serchhip Valley",
        occupation = "Carpenter",
        contact = "+91 98561XXXXX",
        consentStatus = true
      )

      dao.insertPatient(p1)
      dao.insertPatient(p2)
      dao.insertPatient(p3)
      dao.insertPatient(p4)
      dao.insertPatient(p5)

      // Seed assessments
      val a1 = AssessmentEntity(
        id = "asm-001",
        patientId = "p-001",
        workerId = "HW-Aizawl-01",
        affectedJoint = "Knee (Both)",
        painScore = 7,
        painDuration = "6-12 months",
        stiffness = "Morning stiffness > 30m",
        swelling = true,
        mobilityLimitations = "Stair climbing difficulty, walking > 500m",
        previousInjury = true,
        activityLevel = "Heavy physical labor",
        status = "PENDING_REVIEW",
        syncStatus = "SYNCED"
      )

      val a2 = AssessmentEntity(
        id = "asm-002",
        patientId = "p-002",
        workerId = "HW-Lunglei-02",
        affectedJoint = "Knee (Right)",
        painScore = 5,
        painDuration = "3-6 months",
        stiffness = "Morning stiffness < 30m",
        swelling = false,
        mobilityLimitations = "Sit-to-stand difficulty",
        previousInjury = false,
        activityLevel = "Moderate",
        status = "COMPLETED",
        syncStatus = "SYNCED"
      )

      dao.insertAssessment(a1)
      dao.insertAssessment(a2)

      // Seed movement
      dao.insertMovement(
        MovementEntity(
          id = "mov-001",
          assessmentId = "asm-001",
          taskType = "Walking & Sit-to-Stand",
          duration = 30,
          cadence = 88f,
          stepSymmetry = 0.72f,
          movementRange = "Moderate restriction",
          kneeAngleFeatures = "Asymmetrical flexion trajectory (-14 deg right vs left)",
          captureQuality = "Good"
        )
      )

      dao.insertMovement(
        MovementEntity(
          id = "mov-002",
          assessmentId = "asm-002",
          taskType = "Walking & Sit-to-Stand",
          duration = 28,
          cadence = 96f,
          stepSymmetry = 0.89f,
          movementRange = "Mild restriction",
          kneeAngleFeatures = "Symmetrical normal gait cycle",
          captureQuality = "Good"
        )
      )

      // Seed AI results
      dao.insertAiResult(
        AiResultEntity(
          id = "ai-001",
          assessmentId = "asm-001",
          modelVersion = "OA-Screen-v0.1-demo",
          priorityScore = 0.82f,
          priorityCategory = "Higher Review Priority",
          confidence = 0.84f,
          featureContributors = "Activity-related pain, Severe morning stiffness, Movement asymmetry, Previous joint injury",
          explanation = "The screening profile indicates prominent functional limitations and measurable movement asymmetry during walking and sit-to-stand tests, suggesting higher priority for clinical review."
        )
      )

      dao.insertAiResult(
        AiResultEntity(
          id = "ai-002",
          assessmentId = "asm-002",
          modelVersion = "OA-Screen-v0.1-demo",
          priorityScore = 0.38f,
          priorityCategory = "Routine Review",
          confidence = 0.79f,
          featureContributors = "Mild activity pain, Minor sit-to-stand discomfort",
          explanation = "Symptoms are mild with preserved mobility range and balanced movement symmetry. Routine self-management and ergonomic advice recommended."
        )
      )

      // Seed referrals
      dao.insertReferral(
        ReferralEntity(
          id = "ref-001",
          patientId = "p-001",
          assessmentId = "asm-001",
          destination = "District Hospital Orthopedic & Physiotherapy Outpatient Department",
          reason = "Persistent bilateral knee pain with functional stair difficulty and movement asymmetry.",
          priority = "High",
          status = "Active"
        )
      )
    }
  }
}
