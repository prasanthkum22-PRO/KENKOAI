package com.example.data

import kotlinx.coroutines.flow.Flow

class JoniRepository(private val dao: JoniDao) {
  val allPatients: Flow<List<PatientEntity>> = dao.getAllPatients()
  val allAssessments: Flow<List<AssessmentEntity>> = dao.getAllAssessments()
  val allReferrals: Flow<List<ReferralEntity>> = dao.getAllReferrals()

  suspend fun getPatientById(id: String): PatientEntity? = dao.getPatientById(id)

  suspend fun insertPatient(patient: PatientEntity) {
    dao.insertPatient(patient)
    dao.insertSyncQueue(
      SyncQueueEntity(
        recordType = "PATIENT",
        recordId = patient.id,
        operation = "CREATE",
        status = "PENDING"
      )
    )
  }

  fun getAssessmentsForPatient(patientId: String): Flow<List<AssessmentEntity>> =
    dao.getAssessmentsForPatient(patientId)

  suspend fun getAssessmentById(id: String): AssessmentEntity? = dao.getAssessmentById(id)

  suspend fun insertAssessment(assessment: AssessmentEntity): String {
    dao.insertAssessment(assessment)
    dao.insertSyncQueue(
      SyncQueueEntity(
        recordType = "ASSESSMENT",
        recordId = assessment.id,
        operation = "CREATE",
        status = "PENDING"
      )
    )
    return assessment.id
  }

  suspend fun saveMovement(movement: MovementEntity) {
    dao.insertMovement(movement)
  }

  suspend fun getMovement(assessmentId: String): MovementEntity? =
    dao.getMovementForAssessment(assessmentId)

  suspend fun saveAiResult(aiResult: AiResultEntity) {
    dao.insertAiResult(aiResult)
  }

  suspend fun getAiResult(assessmentId: String): AiResultEntity? =
    dao.getAiResultForAssessment(assessmentId)

  suspend fun getClinicalReview(assessmentId: String): ClinicalReviewEntity? =
    dao.getClinicalReview(assessmentId)

  suspend fun saveClinicalReview(review: ClinicalReviewEntity) {
    dao.insertClinicalReview(review)
  }

  suspend fun insertReferral(referral: ReferralEntity) {
    dao.insertReferral(referral)
  }

  suspend fun getPendingSyncItems(): List<SyncQueueEntity> = dao.getPendingSyncItems()

  suspend fun performSync() {
    val pending = dao.getPendingSyncItems()
    for (item in pending) {
      dao.markSynced(item.id)
    }
  }

  suspend fun runAiScreening(
    assessmentId: String,
    painScore: Int,
    mobilityLimitations: String,
    previousInjury: Boolean,
    asymmetryScore: Float
  ): AiResultEntity {
    // Demo ML scoring model logic (Logistic / Random Forest proxy)
    val score = kotlin.math.min(1.0f, (painScore / 10.0f * 0.4f) +
      (if (mobilityLimitations.isNotBlank()) 0.3f else 0.0f) +
      (if (previousInjury) 0.15f else 0.0f) +
      (asymmetryScore * 0.15f))

    val isHighPriority = score >= 0.55f
    val category = if (isHighPriority) "Higher Review Priority" else "Routine Review"
    val confidence = 0.78f + (kotlin.random.Random.Default.nextFloat() * 0.18f)

    val contributors = mutableListOf<String>()
    if (painScore >= 5) contributors.add("Significant activity-related joint pain ($painScore/10)")
    if (mobilityLimitations.isNotBlank()) contributors.add("Reported functional mobility restriction ($mobilityLimitations)")
    if (previousInjury) contributors.add("History of previous joint injury")
    if (asymmetryScore > 0.2f) contributors.add("Measurable movement asymmetry during assessment")
    if (contributors.isEmpty()) contributors.add("Minor discomfort without severe structural indicators")

    val explanation = if (isHighPriority) {
      "The screening model (OA-Screen-v0.1-demo) flagged this case due to combined activity pain, functional restriction, and gait/movement asymmetry indicators. Clinical evaluation and review are recommended."
    } else {
      "The screening model indicates normal or mild symptoms with well-preserved functional mobility and balanced movement symmetry. Routine self-management advice is appropriate."
    }

    val result = AiResultEntity(
      assessmentId = assessmentId,
      modelVersion = "OA-Screen-v0.1-demo",
      priorityScore = score,
      priorityCategory = category,
      confidence = confidence,
      featureContributors = contributors.joinToString("; "),
      explanation = explanation
    )

    dao.insertAiResult(result)
    return result
  }
}
