package com.example.ui.components

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraPermissionCard(
  onCameraReady: () -> Unit
) {
  val context = LocalContext.current
  val cameraPermissionState = rememberPermissionState(permission = Manifest.permission.CAMERA)

  var testCameraOpen by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = JoniSurface),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier.padding(20.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = if (cameraPermissionState.status.isGranted) Icons.Default.Videocam else Icons.Default.VideocamOff,
          contentDescription = null,
          tint = if (cameraPermissionState.status.isGranted) JoniSuccess else JoniWarning,
          modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text("Camera Sensor & Pose Capture", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
          Text(
            when {
              cameraPermissionState.status.isGranted -> "Ready • Camera access granted"
              cameraPermissionState.status.shouldShowRationale -> "Permission required for posture analysis"
              else -> "Permission required for AI movement screening"
            },
            fontSize = 12.sp,
            color = JoniMuted
          )
        }
      }

      Divider(color = JoniBorder)

      when {
        cameraPermissionState.status.isGranted -> {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JoniSuccess, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Camera Permission Granted", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = JoniSuccess)
            }
            Text("Camera is ready to capture participant posture and joint movement stability during screening.", fontSize = 12.sp, color = JoniMuted)

            Spacer(modifier = Modifier.height(4.dp))
            Button(
              onClick = { testCameraOpen = true },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = JoniSecondary)
            ) {
              Icon(Icons.Default.CameraAlt, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text(if (testCameraOpen) "Camera Test Active (Live Preview)" else "Test Camera & Pose Preview")
            }

            if (testCameraOpen) {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .height(360.dp)
                  .clip(RoundedCornerShape(12.dp))
              ) {
                CameraQualityTest(
                  onClose = { testCameraOpen = false },
                  onTestPassed = { testCameraOpen = false }
                )
              }
            }
          }
        }

        cameraPermissionState.status.shouldShowRationale -> {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
              "Camera Access Required for Screening",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = JoniText
            )
            Text(
              "The camera is used solely during the movement assessment to capture body posture and joint kinematics. Raw video is processed on-device.",
              fontSize = 12.sp,
              color = JoniMuted
            )
            Button(
              onClick = { cameraPermissionState.launchPermissionRequest() },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
            ) {
              Icon(Icons.Default.Videocam, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Allow Camera Access")
            }
          }
        }

        else -> {
          // Permanently denied or first time request
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
              "Camera Permission Required",
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp,
              color = JoniText
            )
            Text(
              "Camera access is needed to evaluate joint movement. If previously denied, please enable it in your device settings.",
              fontSize = 12.sp,
              color = JoniMuted
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              Button(
                onClick = { cameraPermissionState.launchPermissionRequest() },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
              ) {
                Text("Try Again")
              }
              OutlinedButton(
                onClick = {
                  val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                  }
                  context.startActivity(intent)
                },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
              ) {
                Text("Open Settings")
              }
            }
          }
        }
      }
    }
  }
}
