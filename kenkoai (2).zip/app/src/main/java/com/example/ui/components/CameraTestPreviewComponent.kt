package com.example.ui.components

import android.content.Context
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun CameraTestPreviewComponent(
  onClose: () -> Unit,
  onQualityPassed: () -> Unit
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  var isCheckingQuality by remember { mutableStateOf(true) }
  var lightingGood by remember { mutableStateOf(false) }
  var stabilityGood by remember { mutableStateOf(false) }
  var bodyVisible by remember { mutableStateOf(false) }
  var distanceSuitable by remember { mutableStateOf(false) }
  var qualityCheckComplete by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  val scope = rememberCoroutineScope()

  // Run automated quality assessment simulation / real check over 2.5 seconds
  LaunchedEffect(Unit) {
    isCheckingQuality = true
    errorMessage = null
    delay(800)
    lightingGood = true
    delay(700)
    stabilityGood = true
    delay(600)
    bodyVisible = true
    distanceSuitable = true
    isCheckingQuality = false
    qualityCheckComplete = true
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color.Black)
  ) {
    // CameraX Preview View
    AndroidView(
      factory = { ctx ->
        PreviewView(ctx).apply {
          scaleType = PreviewView.ScaleType.FILL_CENTER
          implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
      },
      modifier = Modifier.fillMaxSize(),
      update = { previewView ->
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
          try {
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
              it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(
              lifecycleOwner,
              cameraSelector,
              preview
            )
          } catch (e: Exception) {
            // Fallback if camera hardware is busy or unavailable
          }
        }, ContextCompat.getMainExecutor(context))
      }
    )

    // Overlay Guide & UI
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top Header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
          .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("Camera Quality & Pose Check", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Text("Position participant inside the frame", color = JoniMuted, fontSize = 12.sp)
        }
        IconButton(onClick = onClose) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
        }
      }

      // Center Framing Guide & Body Silhouette Box
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .padding(vertical = 24.dp),
        contentAlignment = Alignment.Center
      ) {
        Box(
          modifier = Modifier
            .width(260.dp)
            .height(400.dp)
            .border(
              width = 2.dp,
              color = if (qualityCheckComplete) JoniSuccess else JoniSecondary,
              shape = RoundedCornerShape(24.dp)
            ),
          contentAlignment = Alignment.Center
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Accessibility,
              contentDescription = null,
              tint = if (qualityCheckComplete) JoniSuccess else Color.White.copy(alpha = 0.7f),
              modifier = Modifier.size(64.dp)
            )
            Text(
              text = if (isCheckingQuality) "Analyzing lighting & distance..." else "Full Body Detected ✓",
              color = if (qualityCheckComplete) JoniSuccess else Color.White,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp
            )
          }
        }
      }

      // Quality Metrics Card & Action Bar
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface.copy(alpha = 0.95f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text("Environmental & Pose Quality", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JoniText)

          QualityMetricRow(label = "Lighting condition", passed = lightingGood, detail = if (lightingGood) "Good (> 300 lux)" else "Checking...")
          QualityMetricRow(label = "Camera stability", passed = stabilityGood, detail = if (stabilityGood) "Stable tripod / hold" else "Checking...")
          QualityMetricRow(label = "Participant visibility", passed = bodyVisible, detail = if (bodyVisible) "Full body in frame" else "Detecting...")
          QualityMetricRow(label = "Distance from camera", passed = distanceSuitable, detail = if (distanceSuitable) "2.0m (Optimal)" else "Adjusting...")

          Spacer(modifier = Modifier.height(4.dp))

          if (isCheckingQuality) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = JoniPrimary)
          } else {
            Button(
              onClick = onQualityPassed,
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
            ) {
              Icon(Icons.Default.Check, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Confirm & Start Assessment", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

@Composable
fun QualityMetricRow(label: String, passed: Boolean, detail: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = if (passed) Icons.Default.CheckCircle else Icons.Default.HourglassEmpty,
        contentDescription = null,
        tint = if (passed) JoniSuccess else JoniWarning,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(label, fontSize = 13.sp, color = JoniText, fontWeight = FontWeight.Medium)
    }
    Text(detail, fontSize = 12.sp, color = if (passed) JoniSuccess else JoniMuted, fontWeight = FontWeight.Bold)
  }
}
