package com.example.ui.components

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class CameraState {
  object Idle : CameraState()
  object Initializing : CameraState()
  object Ready : CameraState()
  data class Error(val message: String) : CameraState()
  object PermissionDenied : CameraState()
  object Timeout : CameraState()
}

class CameraViewModel : ViewModel() {
  private val _cameraState = MutableStateFlow<CameraState>(CameraState.Idle)
  val cameraState: StateFlow<CameraState> = _cameraState.asStateFlow()

  fun startInitialization() {
    _cameraState.value = CameraState.Initializing
  }

  fun setReady() {
    _cameraState.value = CameraState.Ready
  }

  fun setError(message: String) {
    _cameraState.value = CameraState.Error(message)
  }

  fun setPermissionDenied() {
    _cameraState.value = CameraState.PermissionDenied
  }

  fun setTimeout() {
    _cameraState.value = CameraState.Timeout
  }

  fun reset() {
    _cameraState.value = CameraState.Idle
  }
}
