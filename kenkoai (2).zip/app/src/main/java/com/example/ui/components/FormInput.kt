package com.example.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.theme.JoniBorder
import com.example.ui.theme.JoniMuted
import com.example.ui.theme.JoniPrimary
import com.example.ui.theme.JoniSurface
import com.example.ui.theme.JoniText

@Composable
fun FormInput(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  modifier: Modifier = Modifier.fillMaxWidth(),
  placeholder: String = "",
  singleLine: Boolean = true,
  maxLines: Int = 1
) {
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    label = { Text(label) },
    placeholder = if (placeholder.isNotEmpty()) { { Text(placeholder, color = JoniMuted) } } else null,
    modifier = modifier,
    singleLine = singleLine,
    maxLines = maxLines,
    shape = RoundedCornerShape(10.dp),
    colors = OutlinedTextFieldDefaults.colors(
      focusedTextColor = JoniText,
      unfocusedTextColor = JoniText,
      disabledTextColor = JoniMuted,
      focusedContainerColor = JoniSurface,
      unfocusedContainerColor = JoniSurface,
      disabledContainerColor = JoniSurface,
      focusedBorderColor = JoniPrimary,
      unfocusedBorderColor = JoniBorder,
      focusedLabelColor = JoniPrimary,
      unfocusedLabelColor = JoniMuted,
      focusedPlaceholderColor = JoniMuted,
      unfocusedPlaceholderColor = JoniMuted
    )
  )
}
