package com.example.ui.i18n

object JoniStrings {
  fun get(key: String, lang: String): String {
    val isHindi = lang == "HI"
    return when (key) {
      "app_title" -> if (isHindi) "जोनी — संयुक्त अवलोकन और नेविगेशन इंटेलिजेंस" else "JONI — Joint Observation & Navigation Intelligence"
      "tagline" -> if (isHindi) "पहले जांच करें। बेहतर संदर्भ दें। तेजी से देखभाल तक पहुंचें।" else "Screen earlier. Refer smarter. Reach care sooner."
      "landing_btn" -> if (isHindi) "डेमो लॉन्च करें" else "Launch Demo"
      "worker_dashboard" -> if (isHindi) "फ्रंटलाइन स्वास्थ्य कार्यकर्ता डैशबोर्ड" else "Frontline Health Worker Dashboard"
      "clinician_dashboard" -> if (isHindi) "चिकित्सक समीक्षा कतार" else "Clinician Review Queue"
      "start_screening" -> if (isHindi) "नई जांच शुरू करें" else "Start New Screening"
      "offline_mode" -> if (isHindi) "ऑफ़लाइन मोड (डेटा स्थानीय रूप से सुरक्षित)" else "Offline Mode (Local Storage Active)"
      "sync_now" -> if (isHindi) "अभी सिंक करें" else "Sync Now"
      "disclaimer" -> if (isHindi) "यह एक प्रयोगात्मक AI-सहायक जांच अनुमान है और यह चिकित्सीय निदान नहीं है।" else "Experimental AI-assisted screening estimate. Not a medical diagnosis."
      else -> key
    }
  }
}
