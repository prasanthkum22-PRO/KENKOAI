package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.*
import com.example.viewmodel.JoniViewModel

@Composable
fun JoniNavGraph(viewModel: JoniViewModel) {
  val navController = rememberNavController()
  val patients by viewModel.patients.collectAsState()
  val assessments by viewModel.assessments.collectAsState()
  val isOnline by viewModel.isOnline.collectAsState()
  val pendingSyncCount by viewModel.pendingSyncCount.collectAsState()
  val currentLang by viewModel.currentLanguage.collectAsState()

  NavHost(navController = navController, startDestination = "landing") {
    composable("landing") {
      LandingScreen(
        onGetStarted = { navController.navigate("worker_dashboard") },
        onOpenLogin = { navController.navigate("login") },
        currentLang = currentLang,
        onToggleLang = { viewModel.setLanguage(if (currentLang == "EN") "HI" else "EN") }
      )
    }

    composable("login") {
      LoginScreen(
        onLoginSuccess = { role ->
          viewModel.setRole(role)
          if (role == "CLINICIAN") {
            navController.navigate("clinician_dashboard") { popUpTo("landing") }
          } else {
            navController.navigate("worker_dashboard") { popUpTo("landing") }
          }
        }
      )
    }

    composable("worker_dashboard") {
      WorkerDashboardScreen(
        patients = patients,
        assessments = assessments,
        isOnline = isOnline,
        pendingSyncCount = pendingSyncCount,
        onStartScreening = {
          if (patients.isNotEmpty()) {
            navController.navigate("screening_wizard/${patients.first().id}")
          } else {
            navController.navigate("patient_registration")
          }
        },
        onRegisterPatient = { navController.navigate("patient_registration") },
        onOpenPatient = { id -> navController.navigate("patient_profile/$id") },
        onOpenSync = { navController.navigate("sync") },
        onOpenClinician = { navController.navigate("clinician_dashboard") },
        onOpenAnalytics = { navController.navigate("analytics") },
        onOpenReports = { navController.navigate("reports") },
        onOpenSettings = { navController.navigate("settings") },
        onOpenMore = { navController.navigate("more") }
      )
    }

    composable("more") {
      MoreScreen(
        onOpenEducation = { navController.navigate("education") },
        onOpenReports = { navController.navigate("reports") },
        onOpenReferrals = { navController.navigate("clinician_dashboard") },
        onOpenFollowUps = { navController.navigate("clinician_dashboard") },
        onOpenSensors = { navController.navigate("settings") },
        onOpenDiagnostics = { navController.navigate("device_diagnostics") },
        onOpenSettings = { navController.navigate("settings") },
        onOpenLanguage = { navController.navigate("settings") },
        onOpenHelp = { navController.navigate("education") },
        onNavigateHome = { navController.navigate("worker_dashboard") { popUpTo("worker_dashboard") { inclusive = true } } },
        onNavigatePatients = { navController.navigate("patient_registration") },
        onStartScreening = {
          if (patients.isNotEmpty()) {
            navController.navigate("screening_wizard/${patients.first().id}")
          } else {
            navController.navigate("patient_registration")
          }
        },
        onNavigateSync = { navController.navigate("sync") }
      )
    }

    composable("patient_registration") {
      PatientRegistrationScreen(
        onBack = { navController.popBackStack() },
        onPatientRegistered = { patientId ->
          navController.navigate("screening_wizard/$patientId") { popUpTo("worker_dashboard") }
        },
        onRegisterAction = { name, age, sex, loc, occ, contact, consent, callback ->
          viewModel.registerPatient(name, age, sex, loc, occ, contact, consent, callback)
        }
      )
    }

    composable(
      route = "patient_profile/{patientId}",
      arguments = listOf(navArgument("patientId") { type = NavType.StringType })
    ) { backStackEntry ->
      val patientId = backStackEntry.arguments?.getString("patientId") ?: ""
      PatientProfileScreen(
        patientId = patientId,
        onBack = { navController.popBackStack() },
        onStartAssessment = { id -> navController.navigate("screening_wizard/$id") },
        getPatientSuspend = { id -> viewModel.getPatient(id) },
        getAssessmentsSuspend = { id -> emptyList() }
      )
    }

    composable(
      route = "screening_wizard/{patientId}",
      arguments = listOf(navArgument("patientId") { type = NavType.StringType })
    ) { backStackEntry ->
      val patientId = backStackEntry.arguments?.getString("patientId") ?: ""
      ScreeningWizardScreen(
        patientId = patientId,
        onBack = { navController.popBackStack() },
        onCompleteWizard = { pId, joint, pain, duration, stiffness, swelling, mobility, injury, activity ->
          viewModel.createAssessment(pId, joint, pain, duration, stiffness, swelling, mobility, injury, activity)
        },
        onProceedToMovement = { asmId ->
          navController.navigate("sensor_assessment/$asmId") { popUpTo("worker_dashboard") }
        }
      )
    }

    composable(
      route = "sensor_assessment/{assessmentId}",
      arguments = listOf(navArgument("assessmentId") { type = NavType.StringType })
    ) { backStackEntry ->
      val assessmentId = backStackEntry.arguments?.getString("assessmentId") ?: ""
      SensorAssessmentScreen(
        assessmentId = assessmentId,
        onBack = { navController.popBackStack() },
        onProceedToMovement = { asmId ->
          navController.navigate("movement/$asmId") { popUpTo("sensor_assessment/$asmId") }
        }
      )
    }

    composable(
      route = "movement/{assessmentId}",
      arguments = listOf(navArgument("assessmentId") { type = NavType.StringType })
    ) { backStackEntry ->
      val assessmentId = backStackEntry.arguments?.getString("assessmentId") ?: ""
      MovementAssessmentScreen(
        assessmentId = assessmentId,
        onCompleteMovement = { asmId, task, dur, cadence, sym, range, features, quality ->
          viewModel.saveMovementAndRunAi(asmId, task, dur, cadence, sym, range, features, quality)
        },
        onNavigateToResult = { asmId ->
          navController.navigate("ai_result/$asmId") { popUpTo("worker_dashboard") }
        }
      )
    }

    composable(
      route = "ai_result/{assessmentId}",
      arguments = listOf(navArgument("assessmentId") { type = NavType.StringType })
    ) { backStackEntry ->
      val assessmentId = backStackEntry.arguments?.getString("assessmentId") ?: ""
      AiResultScreen(
        assessmentId = assessmentId,
        onBackToDashboard = { navController.navigate("worker_dashboard") { popUpTo("landing") } },
        onOpenClinicianReview = { asmId -> navController.navigate("clinical_review/$asmId") },
        getAiResultSuspend = { asmId -> viewModel.getAssessmentDetails(asmId).third }
      )
    }

    composable("sync") {
      SyncScreen(
        isOnline = isOnline,
        pendingSyncCount = pendingSyncCount,
        onToggleOnline = { viewModel.toggleOnlineStatus() },
        onSyncNow = { viewModel.syncNow {} },
        onBack = { navController.popBackStack() }
      )
    }

    composable("clinician_dashboard") {
      ClinicianDashboardScreen(
        assessments = assessments,
        patients = patients,
        onOpenReview = { asmId -> navController.navigate("clinical_review/$asmId") },
        onBackToWorker = { navController.navigate("worker_dashboard") { popUpTo("landing") } }
      )
    }

    composable(
      route = "clinical_review/{assessmentId}",
      arguments = listOf(navArgument("assessmentId") { type = NavType.StringType })
    ) { backStackEntry ->
      val assessmentId = backStackEntry.arguments?.getString("assessmentId") ?: ""
      ClinicalReviewScreen(
        assessmentId = assessmentId,
        onBack = { navController.popBackStack() },
        onReviewCompleted = { navController.navigate("clinician_dashboard") { popUpTo("clinician_dashboard") } },
        getDetailsSuspend = { asmId -> viewModel.getAssessmentDetails(asmId) },
        getPatientSuspend = { id -> viewModel.getPatient(id) },
        saveReviewSuspend = { asmId, clinId, note, rec -> viewModel.saveClinicalReview(asmId, clinId, note, rec) }
      )
    }

    composable("analytics") {
      AnalyticsScreen(onBack = { navController.popBackStack() })
    }

    composable("reports") {
      ReportsScreen(onBack = { navController.popBackStack() })
    }

    composable("settings") {
      SettingsScreen(
        currentLang = currentLang,
        onToggleLang = { viewModel.setLanguage(if (currentLang == "EN") "HI" else "EN") },
        onBack = { navController.popBackStack() },
        onOpenDiagnostics = { navController.navigate("device_diagnostics") },
        onOpenEducation = { navController.navigate("education") }
      )
    }

    composable("education") {
      EducationScreen(onBack = { navController.popBackStack() })
    }

    composable("device_diagnostics") {
      DeviceDiagnosticsScreen(onBack = { navController.popBackStack() })
    }
  }
}
