package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AiResultEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiResultScreen(
  assessmentId: String,
  onBackToDashboard: () -> Unit,
  onOpenClinicianReview: (String) -> Unit,
  getAiResultSuspend: suspend (String) -> AiResultEntity?
) {
  var aiResult by remember { mutableStateOf<AiResultEntity?>(null) }

  LaunchedEffect(assessmentId) {
    aiResult = getAiResultSuspend(assessmentId)
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("AI Screening Result", fontWeight = FontWeight.Bold) },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    if (aiResult == null) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    } else {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .background(JoniBackground)
          .padding(padding)
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        val isHighPriority = aiResult!!.priorityCategory.contains("Higher", ignoreCase = true)

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isHighPriority) JoniWarning.copy(alpha = 0.15f) else JoniSuccess.copy(alpha = 0.15f)
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              imageVector = if (isHighPriority) Icons.Default.PriorityHigh else Icons.Default.CheckCircle,
              contentDescription = null,
              tint = if (isHighPriority) JoniWarning else JoniSuccess,
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = aiResult!!.priorityCategory.uppercase(),
              fontWeight = FontWeight.Bold,
              fontSize = 20.sp,
              color = if (isHighPriority) JoniWarning else JoniSuccess
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Screening Confidence: ${(aiResult!!.confidence * 100).toInt()}% • Model: ${aiResult!!.modelVersion}",
              fontSize = 12.sp,
              color = JoniMuted
            )
          }
        }

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSurface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Why was this priority flagged?", fontWeight = FontWeight.Bold, color = JoniText, fontSize = 16.sp)
            Text(aiResult!!.explanation, color = JoniMuted, fontSize = 14.sp)

            Divider(color = JoniBorder)

            Text("Contributing Indicators:", fontWeight = FontWeight.Bold, color = JoniText, fontSize = 14.sp)
            aiResult!!.featureContributors.split("; ").forEach { indicator ->
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Check, contentDescription = null, tint = JoniPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(indicator, fontSize = 13.sp, color = JoniText)
              }
            }
          }
        }

        Surface(
          shape = RoundedCornerShape(12.dp),
          color = JoniBorder.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Info, contentDescription = null, tint = JoniMuted)
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "Disclaimer: This is an experimental AI-assisted screening estimate and is not a medical diagnosis. Clinical review is required.",
              fontSize = 11.sp,
              color = JoniMuted
            )
          }
        }

        Button(
          onClick = { onOpenClinicianReview(assessmentId) },
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
        ) {
          Icon(Icons.Default.Send, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Send for Clinical Review & Referral", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onBackToDashboard,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("Return to Health Worker Dashboard")
        }
      }
    }
  }
}
