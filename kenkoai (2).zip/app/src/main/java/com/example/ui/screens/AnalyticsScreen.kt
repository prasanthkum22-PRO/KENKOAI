package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsScreen(
  onBack: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Program Analytics & Coverage", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
          Text("Synthetic Demonstration Analytics", fontWeight = FontWeight.Bold, color = JoniPrimary, fontSize = 16.sp)

          AnalyticsBar(title = "Community Screening Coverage", percentage = 0.82f, value = "82%")
          AnalyticsBar(title = "Higher Review Priority Cases", percentage = 0.34f, value = "34%")
          AnalyticsBar(title = "Referral Completion Rate", percentage = 0.78f, value = "78%")
          AnalyticsBar(title = "Offline Assessments Synced", percentage = 1.0f, value = "100%")
        }
      }

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = JoniWarning.copy(alpha = 0.1f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Info, contentDescription = null, tint = JoniWarning)
          Spacer(modifier = Modifier.width(12.dp))
          Text("Metrics reflect synthetic deployment simulation in regional health camps.", fontSize = 12.sp, color = JoniText)
        }
      }
    }
  }
}

@Composable
fun AnalyticsBar(title: String, percentage: Float, value: String) {
  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text(title, fontSize = 13.sp, color = JoniText, fontWeight = FontWeight.SemiBold)
      Text(value, fontSize = 13.sp, color = JoniPrimary, fontWeight = FontWeight.Bold)
    }
    LinearProgressIndicator(
      progress = { percentage },
      modifier = Modifier
        .fillMaxWidth()
        .height(8.dp),
      color = JoniPrimary,
      trackColor = JoniBorder
    )
  }
}
