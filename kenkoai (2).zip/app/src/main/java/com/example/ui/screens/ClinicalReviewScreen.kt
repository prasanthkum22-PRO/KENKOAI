package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AiResultEntity
import com.example.data.AssessmentEntity
import com.example.data.MovementEntity
import com.example.data.PatientEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClinicalReviewScreen(
  assessmentId: String,
  onBack: () -> Unit,
  onReviewCompleted: () -> Unit,
  getDetailsSuspend: suspend (String) -> Triple<AssessmentEntity?, MovementEntity?, AiResultEntity?>,
  getPatientSuspend: suspend (String) -> PatientEntity?,
  saveReviewSuspend: suspend (String, String, String, String) -> Unit
) {
  var assessment by remember { mutableStateOf<AssessmentEntity?>(null) }
  var movement by remember { mutableStateOf<MovementEntity?>(null) }
  var aiResult by remember { mutableStateOf<AiResultEntity?>(null) }
  var patient by remember { mutableStateOf<PatientEntity?>(null) }

  var clinicalNote by remember { mutableStateOf("Patient examined via community screening proxy. Recommended physiotherapy evaluation and graduated strengthening.") }
  var recommendation by remember { mutableStateOf("District Hospital Physiotherapy & Orthopedic Referral") }
  val scope = rememberCoroutineScope()

  LaunchedEffect(assessmentId) {
    val (asm, mov, ai) = getDetailsSuspend(assessmentId)
    assessment = asm
    movement = mov
    aiResult = ai
    if (asm != null) {
      patient = getPatientSuspend(asm.patientId)
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Clinical Case Review", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    if (assessment == null || patient == null) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    } else {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .background(JoniBackground)
          .padding(padding)
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSurface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Patient: ${patient!!.name} (${patient!!.patientCode})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
            Text("Age: ${patient!!.age} • Sex: ${patient!!.sex} • Location: ${patient!!.location}", fontSize = 13.sp, color = JoniMuted)
            Divider(color = JoniBorder, modifier = Modifier.padding(vertical = 4.dp))
            Text("Affected Joint: ${assessment!!.affectedJoint}", fontWeight = FontWeight.SemiBold)
            Text("Pain Score: ${assessment!!.painScore}/10 • Duration: ${assessment!!.painDuration}", fontSize = 13.sp)
            Text("Stiffness: ${assessment!!.stiffness}", fontSize = 13.sp)
            Text("Mobility Limitations: ${assessment!!.mobilityLimitations}", fontSize = 13.sp)
          }
        }

        if (movement != null) {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JoniSurface),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text("Movement Assessment (Camera Capture)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniPrimary)
              Text("Cadence: ${movement!!.cadence} steps/min • Symmetry: ${(movement!!.stepSymmetry * 100).toInt()}%", fontSize = 13.sp)
              Text("Knee Angle Features: ${movement!!.kneeAngleFeatures}", fontSize = 13.sp, color = JoniMuted)
            }
          }
        }

        if (aiResult != null) {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JoniSurface),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text("AI Screening Estimate (${aiResult!!.modelVersion})", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniSecondary)
              Text("Priority: ${aiResult!!.priorityCategory}", fontWeight = FontWeight.Bold, color = JoniWarning)
              Text(aiResult!!.explanation, fontSize = 13.sp, color = JoniText)
            }
          }
        }

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSurface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Clinician Assessment & Recommendation", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)

            OutlinedTextField(
              value = clinicalNote,
              onValueChange = { clinicalNote = it },
              label = { Text("Clinical Note / Observations") },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = JoniText,
                unfocusedTextColor = JoniText,
                focusedContainerColor = JoniSurface,
                unfocusedContainerColor = JoniSurface
              )
            )

            OutlinedTextField(
              value = recommendation,
              onValueChange = { recommendation = it },
              label = { Text("Referral Destination / Plan") },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = JoniText,
                unfocusedTextColor = JoniText,
                focusedContainerColor = JoniSurface,
                unfocusedContainerColor = JoniSurface
              )
            )
          }
        }

        Button(
          onClick = {
            scope.launch {
              saveReviewSuspend(
                assessmentId,
                "DR-ZOTHAN-01",
                clinicalNote,
                recommendation
              )
              onReviewCompleted()
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
        ) {
          Icon(Icons.Default.Check, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Authorize Review & Referral", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
