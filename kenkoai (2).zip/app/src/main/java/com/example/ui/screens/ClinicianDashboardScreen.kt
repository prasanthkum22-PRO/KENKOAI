package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AssessmentEntity
import com.example.data.PatientEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClinicianDashboardScreen(
  assessments: List<AssessmentEntity>,
  patients: List<PatientEntity>,
  onOpenReview: (String) -> Unit,
  onBackToWorker: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text("Clinician Review Queue", fontWeight = FontWeight.Bold, color = JoniPrimary, fontSize = 18.sp)
            Text("District Orthopedic & Physiotherapy Hub", fontSize = 12.sp, color = JoniMuted)
          }
        },
        actions = {
          TextButton(onClick = onBackToWorker) {
            Text("Worker View", fontWeight = FontWeight.Bold, color = JoniSecondary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSurface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.LocalHospital, contentDescription = null, tint = JoniPrimary, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column {
              Text("Priority Review Queue", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
              Text("Review flagged community assessments and authorize clinical referrals.", fontSize = 12.sp, color = JoniMuted)
            }
          }
        }
      }

      items(assessments) { assessment ->
        val patient = patients.find { it.id == assessment.patientId }
        val isHigh = assessment.painScore >= 6

        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSurface),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenReview(assessment.id) }
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = patient?.name ?: "Demo Patient",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = JoniText
              )
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isHigh) JoniWarning.copy(alpha = 0.15f) else JoniSuccess.copy(alpha = 0.15f)
              ) {
                Text(
                  text = if (isHigh) "Higher Priority" else "Routine Review",
                  color = if (isHigh) JoniWarning else JoniSuccess,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Text("Joint: ${assessment.affectedJoint} • Pain Score: ${assessment.painScore}/10", fontSize = 13.sp, color = JoniMuted)
            Text("Mobility Limitations: ${assessment.mobilityLimitations}", fontSize = 12.sp, color = JoniText)

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End
            ) {
              TextButton(onClick = { onOpenReview(assessment.id) }) {
                Text("Open Clinical Review →", fontWeight = FontWeight.Bold, color = JoniPrimary)
              }
            }
          }
        }
      }
    }
  }
}
