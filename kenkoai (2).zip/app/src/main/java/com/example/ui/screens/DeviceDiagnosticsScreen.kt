package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceDiagnosticsScreen(onBack: () -> Unit) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Hardware & Device Diagnostics", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Text("System Health & Sensor Calibration Check", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)

      DiagnosticItem("Camera Hardware & Pose Landmarker", "Operational (60 FPS)", true)
      DiagnosticItem("Smartphone Accelerometer Sensor", "Calibrated (9.81 m/s²)", true)
      DiagnosticItem("Gyroscope Rotation Sensor", "Active & Stable", true)
      DiagnosticItem("Bluetooth Low Energy (BLE Kit)", "Connected (ESP32-IMU-01)", true)
      DiagnosticItem("Local Room SQLite Database", "Encrypted & Operational", true)
      DiagnosticItem("Offline AI Screening Engine", "Model Loaded (v0.1-demo)", true)
      DiagnosticItem("Cloud Sync Status", "Pending 3 Records (Offline Mode)", false)
    }
  }
}

@Composable
fun DiagnosticItem(title: String, status: String, isOk: Boolean) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = JoniSurface),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = if (isOk) Icons.Default.CheckCircle else Icons.Default.Warning,
        contentDescription = null,
        tint = if (isOk) JoniSuccess else JoniWarning
      )
      Spacer(modifier = Modifier.width(16.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JoniText)
        Text(status, fontSize = 12.sp, color = JoniMuted)
      }
      Text(if (isOk) "PASS" else "SYNC", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (isOk) JoniSuccess else JoniWarning)
    }
  }
}
