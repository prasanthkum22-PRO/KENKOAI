package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EducationScreen(onBack: () -> Unit) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Joint Health & Patient Education", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      EducationCard(
        title = "Understanding Osteoarthritis (OA)",
        description = "Osteoarthritis is a common degenerative joint condition where protective cartilage cushioning bones gradually wears down over time. Early screening helps manage symptoms effectively through lifestyle guidance and timely clinical review.",
        icon = Icons.Default.Info
      )

      EducationCard(
        title = "Staying Physically Active",
        description = "Low-impact aerobic activities like walking, cycling, and gentle water exercises strengthen muscles supporting the knee and hip joints without placing excessive strain.",
        icon = Icons.Default.DirectionsWalk
      )

      EducationCard(
        title = "Safe Movement & Ergonomics",
        description = "Maintain proper posture when standing up from chairs, avoid prolonged squatting or heavy impact twisting, and use supportive footwear during daily rural and field activities.",
        icon = Icons.Default.AccessibilityNew
      )

      EducationCard(
        title = "When to Seek Clinical Evaluation",
        description = "Consult a medical specialist or orthopedic doctor if you experience persistent swelling, locking sensation in joints, severe night pain, or inability to bear weight.",
        icon = Icons.Default.LocalHospital
      )
    }
  }
}

@Composable
fun EducationCard(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = JoniSurface),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(20.dp),
      verticalAlignment = Alignment.Top
    ) {
      Icon(imageVector = icon, contentDescription = null, tint = JoniPrimary, modifier = Modifier.size(32.dp))
      Spacer(modifier = Modifier.width(16.dp))
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
        Text(description, fontSize = 13.sp, color = JoniMuted, lineHeight = 18.sp)
      }
    }
  }
}
