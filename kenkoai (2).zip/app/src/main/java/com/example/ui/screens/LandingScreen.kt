package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LandingScreen(
  onGetStarted: () -> Unit,
  onOpenLogin: () -> Unit,
  currentLang: String,
  onToggleLang: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = JoniPrimary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("KENKOAI", fontWeight = FontWeight.Bold, color = JoniPrimary)
          }
        },
        actions = {
          TextButton(onClick = onToggleLang) {
            Text(if (currentLang == "EN") "हिंदी" else "English", fontWeight = FontWeight.Bold)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Spacer(modifier = Modifier.height(16.dp))

      Surface(
        shape = RoundedCornerShape(32.dp),
        color = JoniPrimary.copy(alpha = 0.1f),
        modifier = Modifier.padding(bottom = 16.dp)
      ) {
        Text(
          text = "  AI-Assisted OA Screening Platform  ",
          color = JoniPrimary,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
          fontSize = 13.sp
        )
      }

      Text(
        text = "Screen earlier. Refer smarter. Reach care sooner.",
        style = MaterialTheme.typography.headlineLarge,
        fontWeight = FontWeight.Bold,
        color = JoniText,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
      )

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "An offline-first mobile screening tool designed for frontline healthcare workers to capture osteoarthritis-related symptoms, mobility markers, and generate explainable risk estimates.",
        style = MaterialTheme.typography.bodyLarge,
        color = JoniMuted,
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
      )

      Spacer(modifier = Modifier.height(32.dp))

      Button(
        onClick = onGetStarted,
        modifier = Modifier
          .fillMaxWidth()
          .height(56.dp)
          .testTag("launch_demo_button"),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Launch Joni Demo", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(12.dp))

      OutlinedButton(
        onClick = onOpenLogin,
        modifier = Modifier
          .fillMaxWidth()
          .height(56.dp),
        shape = RoundedCornerShape(16.dp)
      ) {
        Icon(Icons.Default.Login, contentDescription = null, tint = JoniSecondary)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Worker & Clinician Login", color = JoniSecondary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(40.dp))

      Text(
        text = "Core Architecture & Workflow",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = JoniText,
        modifier = Modifier.align(Alignment.Start)
      )

      Spacer(modifier = Modifier.height(16.dp))

      FeatureCard(
        icon = Icons.Default.CloudOff,
        title = "Offline-First Field Ready",
        desc = "Complete patient registrations and symptom assessments locally in remote areas with background synchronization."
      )
      Spacer(modifier = Modifier.height(12.dp))
      FeatureCard(
        icon = Icons.Default.CameraAlt,
        title = "Camera Movement Assessment",
        desc = "Capture simple gait and sit-to-stand markers with pose landmark estimation to extract functional mobility insights."
      )
      Spacer(modifier = Modifier.height(12.dp))
      FeatureCard(
        icon = Icons.Default.Psychology,
        title = "Explainable AI Risk Estimation",
        desc = "Transparent priority scoring showing exact contributing indicators with required clinical review safeguards."
      )

      Spacer(modifier = Modifier.height(32.dp))

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = JoniWarning.copy(alpha = 0.1f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Info, contentDescription = null, tint = JoniWarning)
          Spacer(modifier = Modifier.width(12.dp))
          Text(
            text = "Notice: JONI is an experimental AI-assisted screening support tool and does not provide medical diagnoses. Clinical review is required.",
            fontSize = 12.sp,
            color = JoniText
          )
        }
      }
    }
  }
}

@Composable
fun FeatureCard(icon: ImageVector, title: String, desc: String) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = JoniSurface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = JoniPrimary.copy(alpha = 0.1f),
        modifier = Modifier.size(48.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(icon, contentDescription = null, tint = JoniPrimary)
        }
      }
      Spacer(modifier = Modifier.width(16.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(title, fontWeight = FontWeight.Bold, color = JoniText, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(desc, color = JoniMuted, fontSize = 13.sp)
      }
    }
  }
}
