package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
  onLoginSuccess: (String) -> Unit
) {
  var selectedRole by remember { mutableStateOf("WORKER") }
  var email by remember { mutableStateOf("worker.aizawl@joni.health") }
  var password by remember { mutableStateOf("••••••••") }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("KENKOAI Secure Portal Login", fontWeight = FontWeight.Bold, color = JoniPrimary) },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Surface(
        shape = RoundedCornerShape(24.dp),
        color = JoniSurface,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(24.dp)) {
          Text("Select User Role", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = JoniText)
          Spacer(modifier = Modifier.height(12.dp))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RoleChip(
              title = "Health Worker",
              icon = Icons.Default.Engineering,
              selected = selectedRole == "WORKER",
              onClick = {
                selectedRole = "WORKER"
                email = "worker.aizawl@joni.health"
              },
              modifier = Modifier.weight(1f)
            )
            RoleChip(
              title = "Clinician",
              icon = Icons.Default.LocalHospital,
              selected = selectedRole == "CLINICIAN",
              onClick = {
                selectedRole = "CLINICIAN"
                email = "dr.zothanpuii@hospital.joni"
              },
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(20.dp))

          OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("User Email / ID") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = JoniText,
              unfocusedTextColor = JoniText,
              focusedContainerColor = JoniSurface,
              unfocusedContainerColor = JoniSurface
            )
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Secure Password") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = JoniText,
              unfocusedTextColor = JoniText,
              focusedContainerColor = JoniSurface,
              unfocusedContainerColor = JoniSurface
            )
          )

          Spacer(modifier = Modifier.height(24.dp))

          Button(
            onClick = { onLoginSuccess(selectedRole) },
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("login_submit_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
          ) {
            Text("Access Joni Portal", fontSize = 16.sp, fontWeight = FontWeight.Bold)
          }
        }
      }

      Spacer(modifier = Modifier.height(20.dp))
      Text("Synthetic Demo Mode Active • Offline-First Storage Enabled", fontSize = 12.sp, color = JoniMuted)
    }
  }
}

@Composable
fun RoleChip(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
  OutlinedButton(
    onClick = onClick,
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    colors = ButtonDefaults.outlinedButtonColors(
      containerColor = if (selected) JoniPrimary.copy(alpha = 0.1f) else JoniSurface
    ),
    border = androidx.compose.foundation.BorderStroke(
      width = if (selected) 2.dp else 1.dp,
      color = if (selected) JoniPrimary else JoniBorder
    )
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier.padding(vertical = 8.dp)
    ) {
      Icon(icon, contentDescription = null, tint = if (selected) JoniPrimary else JoniMuted)
      Spacer(modifier = Modifier.height(4.dp))
      Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (selected) JoniPrimary else JoniText)
    }
  }
}
