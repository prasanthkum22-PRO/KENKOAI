package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(
  onOpenEducation: () -> Unit,
  onOpenReports: () -> Unit,
  onOpenReferrals: () -> Unit,
  onOpenFollowUps: () -> Unit,
  onOpenSensors: () -> Unit,
  onOpenDiagnostics: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenLanguage: () -> Unit,
  onOpenHelp: () -> Unit,
  onNavigateHome: () -> Unit,
  onNavigatePatients: () -> Unit,
  onStartScreening: () -> Unit,
  onNavigateSync: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("More & Secondary Features", fontWeight = FontWeight.Bold, color = JoniPrimary) },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    },
    bottomBar = {
      NavigationBar(containerColor = JoniSurface) {
        NavigationBarItem(
          icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
          label = { Text("Home") },
          selected = false,
          onClick = onNavigateHome
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.People, contentDescription = null) },
          label = { Text("Patients") },
          selected = false,
          onClick = onNavigatePatients
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.AddCircle, contentDescription = null, tint = JoniPrimary) },
          label = { Text("Screen", fontWeight = FontWeight.Bold) },
          selected = false,
          onClick = onStartScreening
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.Sync, contentDescription = null) },
          label = { Text("Sync") },
          selected = false,
          onClick = onNavigateSync
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.MoreHoriz, contentDescription = null) },
          label = { Text("More") },
          selected = true,
          onClick = {}
        )
      }
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Text("CARE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = JoniMuted)
      Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = JoniSurface)) {
        Column {
          MoreMenuItem(icon = Icons.Default.MenuBook, title = "Education & Joint Health", subtitle = "Patient care & movement guides", onClick = onOpenEducation)
          Divider(color = JoniBorder)
          MoreMenuItem(icon = Icons.Default.Assessment, title = "Reports", subtitle = "Printable screening summaries", onClick = onOpenReports)
          Divider(color = JoniBorder)
          MoreMenuItem(icon = Icons.Default.Send, title = "Referrals", subtitle = "Specialist & PHC referral tracking", onClick = onOpenReferrals)
          Divider(color = JoniBorder)
          MoreMenuItem(icon = Icons.Default.EventRepeat, title = "Follow-ups", subtitle = "Scheduled check-ins & timelines", onClick = onOpenFollowUps)
        }
      }

      Text("DEVICES", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = JoniMuted)
      Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = JoniSurface)) {
        Column {
          MoreMenuItem(icon = Icons.Default.Bluetooth, title = "Connected Sensors", subtitle = "ESP32 / BLE shank IMUs & phone IMU", onClick = onOpenSensors)
          Divider(color = JoniBorder)
          MoreMenuItem(icon = Icons.Default.HealthAndSafety, title = "Device Diagnostics", subtitle = "Hardware, camera & sensor check", onClick = onOpenDiagnostics)
        }
      }

      Text("APP", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = JoniMuted)
      Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = JoniSurface)) {
        Column {
          MoreMenuItem(icon = Icons.Default.Settings, title = "Settings", subtitle = "Account & offline storage preferences", onClick = onOpenSettings)
          Divider(color = JoniBorder)
          MoreMenuItem(icon = Icons.Default.Language, title = "Language", subtitle = "English, Hindi, Assamese", onClick = onOpenLanguage)
          Divider(color = JoniBorder)
          MoreMenuItem(icon = Icons.Default.Help, title = "Help & Support", subtitle = "Field screening guidelines & FAQ", onClick = onOpenHelp)
        }
      }
    }
  }
}

@Composable
fun MoreMenuItem(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(16.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(icon, contentDescription = null, tint = JoniPrimary, modifier = Modifier.size(24.dp))
    Spacer(modifier = Modifier.width(16.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JoniText)
      Text(subtitle, fontSize = 12.sp, color = JoniMuted)
    }
    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = JoniMuted)
  }
}
