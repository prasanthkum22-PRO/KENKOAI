package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovementAssessmentScreen(
  assessmentId: String,
  onCompleteMovement: suspend (String, String, Int, Float, Float, String, String, String) -> Unit,
  onNavigateToResult: (String) -> Unit
) {
  var isCapturing by remember { mutableStateOf(false) }
  var countdown by remember { mutableIntStateOf(5) }
  var captureComplete by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Movement & Gait Assessment", fontWeight = FontWeight.Bold) },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniText),
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
      ) {
        Box(
          modifier = Modifier.fillMaxSize(),
          contentAlignment = Alignment.Center
        ) {
          if (!isCapturing && !captureComplete) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
              Icon(Icons.Default.CameraAlt, contentDescription = null, tint = JoniSurface, modifier = Modifier.size(64.dp))
              Spacer(modifier = Modifier.height(16.dp))
              Text("Position patient 2-3 meters from phone camera", color = JoniSurface, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
              Spacer(modifier = Modifier.height(8.dp))
              Text("Captures walking segment & sit-to-stand motion for pose landmark feature extraction.", color = JoniSurface.copy(alpha = 0.7f), fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
          } else if (isCapturing) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              CircularProgressIndicator(color = JoniSurface, modifier = Modifier.size(64.dp))
              Spacer(modifier = Modifier.height(16.dp))
              Text("Analyzing Movement Landmarks... ($countdown s)", color = JoniSurface, fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(8.dp))
              Text("Extracting cadence, step timing & knee angle trajectory", color = JoniSurface.copy(alpha = 0.7f), fontSize = 12.sp)
            }
          } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JoniSuccess, modifier = Modifier.size(64.dp))
              Spacer(modifier = Modifier.height(16.dp))
              Text("Movement Capture Successful!", color = JoniSurface, fontWeight = FontWeight.Bold, fontSize = 18.sp)
              Spacer(modifier = Modifier.height(8.dp))
              Text("Cadence: 88 steps/min • Symmetry: 72% • Range: Moderate", color = JoniSurface.copy(alpha = 0.8f), fontSize = 13.sp)
            }
          }
        }
      }

      if (!isCapturing && !captureComplete) {
        Button(
          onClick = {
            isCapturing = true
            scope.launch {
              for (i in 5 downTo 1) {
                countdown = i
                delay(1000)
              }
              isCapturing = false
              captureComplete = true
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("start_camera_capture_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
        ) {
          Icon(Icons.Default.Videocam, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Start Camera Capture & Pose Analysis", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        TextButton(onClick = {
          scope.launch {
            onCompleteMovement(
              assessmentId,
              "Standard Walk & Sit-to-Stand",
              30,
              88f,
              0.72f,
              "Moderate restriction",
              "Asymmetrical flexion trajectory",
              "Good"
            )
            onNavigateToResult(assessmentId)
          }
        }) {
          Text("Skip Camera / Enter Manual Estimate", color = JoniMuted)
        }
      } else if (captureComplete) {
        Button(
          onClick = {
            scope.launch {
              onCompleteMovement(
                assessmentId,
                "Standard Walk & Sit-to-Stand",
                30,
                88f,
                0.72f,
                "Moderate restriction",
                "Asymmetrical flexion trajectory",
                "Good"
              )
              onNavigateToResult(assessmentId)
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(54.dp),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
        ) {
          Text("Run AI Screening Analysis", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}
