package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AssessmentEntity
import com.example.data.PatientEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientProfileScreen(
  patientId: String,
  onBack: () -> Unit,
  onStartAssessment: (String) -> Unit,
  getPatientSuspend: suspend (String) -> PatientEntity?,
  getAssessmentsSuspend: (String) -> List<AssessmentEntity>
) {
  var patient by remember { mutableStateOf<PatientEntity?>(null) }
  var assessments by remember { mutableStateOf<List<AssessmentEntity>>(emptyList()) }

  LaunchedEffect(patientId) {
    patient = getPatientSuspend(patientId)
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Patient Clinical File", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    if (patient == null) {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    } else {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .background(JoniBackground)
          .padding(padding)
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSurface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = JoniPrimary.copy(alpha = 0.1f),
                modifier = Modifier.size(50.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(Icons.Default.Person, contentDescription = null, tint = JoniPrimary)
                }
              }
              Spacer(modifier = Modifier.width(16.dp))
              Column {
                Text(patient!!.name, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = JoniText)
                Text("Code: ${patient!!.patientCode} • ${patient!!.age} yrs • ${patient!!.sex}", color = JoniMuted, fontSize = 13.sp)
              }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = JoniBorder)
            Spacer(modifier = Modifier.height(16.dp))

            InfoRow(label = "Location / Sector", value = patient!!.location)
            Spacer(modifier = Modifier.height(8.dp))
            InfoRow(label = "Occupation", value = patient!!.occupation)
            Spacer(modifier = Modifier.height(8.dp))
            InfoRow(label = "Contact", value = patient!!.contact)
            Spacer(modifier = Modifier.height(8.dp))
            InfoRow(label = "Consent Status", value = if (patient!!.consentStatus) "Obtained (Signed/Verified)" else "Pending")
          }
        }

        Button(
          onClick = { onStartAssessment(patientId) },
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
        ) {
          Icon(Icons.Default.AddCircle, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Start New OA Screening", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun InfoRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(label, color = JoniMuted, fontSize = 13.sp)
    Text(value, fontWeight = FontWeight.SemiBold, color = JoniText, fontSize = 13.sp)
  }
}
