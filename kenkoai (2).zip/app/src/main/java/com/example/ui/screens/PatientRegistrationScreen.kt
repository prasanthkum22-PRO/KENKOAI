package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientRegistrationScreen(
  onBack: () -> Unit,
  onPatientRegistered: (String) -> Unit,
  onRegisterAction: (String, Int, String, String, String, String, Boolean, (String) -> Unit) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var ageStr by remember { mutableStateOf("") }
  var sex by remember { mutableStateOf("Female") }
  var location by remember { mutableStateOf("Aizawl Rural Sector") }
  var occupation by remember { mutableStateOf("Agricultural Worker") }
  var contact by remember { mutableStateOf("+91 ") }
  var consent by remember { mutableStateOf(true) }

  var showSuccessDialog by remember { mutableStateOf(false) }
  var registeredPatientId by remember { mutableStateOf("") }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Register Patient", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("Patient Demographic Profile", fontWeight = FontWeight.Bold, color = JoniPrimary, fontSize = 16.sp)

          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Full Name") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = JoniText,
              unfocusedTextColor = JoniText,
              focusedContainerColor = JoniSurface,
              unfocusedContainerColor = JoniSurface
            )
          )

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
              value = ageStr,
              onValueChange = { ageStr = it },
              label = { Text("Age (Years)") },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = JoniText,
                unfocusedTextColor = JoniText,
                focusedContainerColor = JoniSurface,
                unfocusedContainerColor = JoniSurface
              )
            )
            OutlinedTextField(
              value = sex,
              onValueChange = { sex = it },
              label = { Text("Sex") },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = JoniText,
                unfocusedTextColor = JoniText,
                focusedContainerColor = JoniSurface,
                unfocusedContainerColor = JoniSurface
              )
            )
          }

          OutlinedTextField(
            value = location,
            onValueChange = { location = it },
            label = { Text("Village / Sector / Location") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = JoniText,
              unfocusedTextColor = JoniText,
              focusedContainerColor = JoniSurface,
              unfocusedContainerColor = JoniSurface
            )
          )

          OutlinedTextField(
            value = occupation,
            onValueChange = { occupation = it },
            label = { Text("Occupation") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = JoniText,
              unfocusedTextColor = JoniText,
              focusedContainerColor = JoniSurface,
              unfocusedContainerColor = JoniSurface
            )
          )

          OutlinedTextField(
            value = contact,
            onValueChange = { contact = it },
            label = { Text("Contact Phone") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = JoniText,
              unfocusedTextColor = JoniText,
              focusedContainerColor = JoniSurface,
              unfocusedContainerColor = JoniSurface
            )
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Checkbox(checked = consent, onCheckedChange = { consent = it })
            Spacer(modifier = Modifier.width(8.dp))
            Text("Patient Informed Consent Obtained for Screening & Data Record", fontSize = 13.sp, color = JoniText)
          }
        }
      }

      Button(
        onClick = {
          val age = ageStr.toIntOrNull() ?: 50
          if (name.isNotBlank()) {
            onRegisterAction(name, age, sex, location, occupation, contact, consent) { id ->
              registeredPatientId = id
              showSuccessDialog = true
            }
          }
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
      ) {
        Icon(Icons.Default.Save, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Save Patient & Proceed to Screening", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    }
  }

  if (showSuccessDialog) {
    AlertDialog(
      onDismissRequest = {},
      title = { Text("Patient Registered Locally") },
      text = { Text("Patient profile saved successfully in local offline queue. Ready for OA screening.") },
      confirmButton = {
        Button(onClick = { onPatientRegistered(registeredPatientId) }) {
          Text("Start Screening Now")
        }
      }
    )
  }
}
