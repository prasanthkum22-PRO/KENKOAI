package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
  onBack: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Screening & Referral Report", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("JONI Screening Summary Report", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = JoniPrimary)
          Text("Generated: 2026-09-07 • Sector: Aizawl Rural", fontSize = 12.sp, color = JoniMuted)
          Divider(color = JoniBorder)
          Text("Total Screened: 45 patients", fontSize = 14.sp)
          Text("Higher Review Priority: 15 cases", fontSize = 14.sp)
          Text("Routine Review: 30 cases", fontSize = 14.sp)
          Text("Referrals Authorized: 12 cases", fontSize = 14.sp)
        }
      }

      Button(
        onClick = {},
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
      ) {
        Icon(Icons.Default.Print, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Export / Print Report (PDF)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}
