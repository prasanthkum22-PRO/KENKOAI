package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.RadioOption
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreeningWizardScreen(
  patientId: String,
  onBack: () -> Unit,
  onCompleteWizard: suspend (String, String, Int, String, String, Boolean, String, Boolean, String) -> String,
  onProceedToMovement: (String) -> Unit
) {
  var currentStep by remember { mutableStateOf(1) }
  val totalSteps = 4

  // Step 1: Joint
  var affectedJoint by remember { mutableStateOf("Knee (Both)") }

  // Step 2: Symptoms
  var painScore by remember { mutableFloatStateOf(6f) }
  var painDuration by remember { mutableStateOf("6-12 months") }
  var stiffness by remember { mutableStateOf("Morning stiffness > 30m") }
  var swelling by remember { mutableStateOf(true) }

  // Step 3: Mobility
  var mobilityLimitation by remember { mutableStateOf("Stair climbing and walking > 500m difficulty") }

  // Step 4: Context
  var previousInjury by remember { mutableStateOf(true) }
  var activityLevel by remember { mutableStateOf("Heavy physical labor") }

  val scope = rememberCoroutineScope()

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text("Step $currentStep of $totalSteps", fontSize = 12.sp, color = JoniMuted, fontWeight = FontWeight.Bold)
            Text(
              when (currentStep) {
                1 -> "Primary Affected Joint"
                2 -> "Symptoms & Pain Characteristics"
                3 -> "Functional Mobility"
                else -> "History & Load"
              },
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = JoniText
            )
          }
        },
        navigationIcon = {
          IconButton(onClick = { if (currentStep > 1) currentStep-- else onBack() }) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
    ) {
      LinearProgressIndicator(
        progress = { currentStep / totalSteps.toFloat() },
        modifier = Modifier
          .fillMaxWidth()
          .height(4.dp),
        color = JoniPrimary,
        trackColor = JoniBorder
      )

      Column(
        modifier = Modifier
          .weight(1f)
          .verticalScroll(rememberScrollState())
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSurface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            when (currentStep) {
              1 -> {
                Text("Select Primary Affected Joint", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = JoniPrimary)
                Text("Choose the joint exhibiting symptoms or functional discomfort:", fontSize = 13.sp, color = JoniMuted)

                val joints = listOf("Knee (Left)", "Knee (Right)", "Knee (Both)", "Hip (Left/Right)", "Spine / Lower Back", "Hand / Wrist")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  joints.forEach { joint ->
                    RadioOption(
                      text = joint,
                      selected = affectedJoint == joint,
                      onClick = { affectedJoint = joint }
                    )
                  }
                }
              }

              2 -> {
                Text("Symptoms & Pain Characteristics", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = JoniPrimary)
                Text("Assess pain severity, duration, stiffness, and clinical swelling markers.", fontSize = 13.sp, color = JoniMuted)

                Divider(color = JoniBorder)

                Text("Pain Severity Score: ${painScore.toInt()} / 10", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JoniText)
                Slider(
                  value = painScore,
                  onValueChange = { painScore = it },
                  valueRange = 0f..10f,
                  steps = 9,
                  colors = SliderDefaults.colors(thumbColor = JoniPrimary, activeTrackColor = JoniPrimary)
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text("Pain Duration:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JoniText)
                val durations = listOf("< 3 months", "3-6 months", "6-12 months", "> 1 year")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  durations.forEach { d ->
                    RadioOption(
                      text = d,
                      selected = painDuration == d,
                      onClick = { painDuration = d }
                    )
                  }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("Morning Stiffness:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JoniText)
                val stiffnessOpts = listOf("None", "Morning stiffness < 30m", "Morning stiffness > 30m")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  stiffnessOpts.forEach { s ->
                    RadioOption(
                      text = s,
                      selected = stiffness == s,
                      onClick = { stiffness = s }
                    )
                  }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .background(JoniSurface, RoundedCornerShape(10.dp))
                    .padding(vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Checkbox(
                    checked = swelling,
                    onCheckedChange = { swelling = it },
                    colors = CheckboxDefaults.colors(checkedColor = JoniPrimary)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Noticeable Joint Swelling / Effusion Reported", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = JoniText)
                }
              }

              3 -> {
                Text("Functional Mobility Limitations", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = JoniPrimary)
                Text("Describe any difficulty experienced during daily activities:", fontSize = 13.sp, color = JoniMuted)

                val mobilityOpts = listOf(
                  "Stair climbing and walking > 500m difficulty",
                  "Sit-to-standing from chair difficulty",
                  "Squatting or kneeling limitation",
                  "Mild stiffness without functional restriction"
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  mobilityOpts.forEach { opt ->
                    RadioOption(
                      text = opt,
                      selected = mobilityLimitation == opt,
                      onClick = { mobilityLimitation = opt }
                    )
                  }
                }
              }

              4 -> {
                Text("History & Occupational Load", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = JoniPrimary)
                Text("Provide patient history and physical load background.", fontSize = 13.sp, color = JoniMuted)

                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .background(JoniSurface, RoundedCornerShape(10.dp))
                    .padding(vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Checkbox(
                    checked = previousInjury,
                    onCheckedChange = { previousInjury = it },
                    colors = CheckboxDefaults.colors(checkedColor = JoniPrimary)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("History of Previous Joint Injury / Trauma", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = JoniText)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("Activity Level & Physical Load:", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = JoniText)
                val activities = listOf("Sedentary / Light", "Moderate Physical Activity", "Heavy physical labor / Farming")
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  activities.forEach { act ->
                    RadioOption(
                      text = act,
                      selected = activityLevel == act,
                      onClick = { activityLevel = act }
                    )
                  }
                }
              }
            }
          }
        }
      }

      Surface(
        color = JoniSurface,
        tonalElevation = 8.dp,
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (currentStep > 1) {
            OutlinedButton(
              onClick = { currentStep-- },
              modifier = Modifier
                .weight(1f)
                .height(48.dp),
              shape = RoundedCornerShape(12.dp)
            ) {
              Text("Back", fontWeight = FontWeight.Bold)
            }
          }

          Button(
            onClick = {
              if (currentStep < totalSteps) {
                currentStep++
              } else {
                scope.launch {
                  val asmId = onCompleteWizard(
                    patientId,
                    affectedJoint,
                    painScore.toInt(),
                    painDuration,
                    stiffness,
                    swelling,
                    mobilityLimitation,
                    previousInjury,
                    activityLevel
                  )
                  onProceedToMovement(asmId)
                }
              }
            },
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("wizard_next_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
          ) {
            Text(if (currentStep < totalSteps) "Continue" else "Proceed to Movement", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}
