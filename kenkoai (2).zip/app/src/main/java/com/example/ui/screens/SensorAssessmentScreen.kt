package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CameraPermissionCard
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SensorAssessmentScreen(
  assessmentId: String,
  onBack: () -> Unit,
  onProceedToMovement: (String) -> Unit
) {
  var isScanning by remember { mutableStateOf(false) }
  var leftConnected by remember { mutableStateOf(true) }
  var rightConnected by remember { mutableStateOf(false) }
  var phoneImuActive by remember { mutableStateOf(true) }
  var calibrating by remember { mutableStateOf(false) }
  var calibrationDone by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("BLE & IMU Sensor Hub", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      CameraPermissionCard(
        onCameraReady = {}
      )

      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Bluetooth, contentDescription = null, tint = JoniPrimary, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("Optional Sensor Kit (ESP32 / IMU)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
              Text("Connect lower-limb wearables for gait & balance metrics alongside camera AI.", fontSize = 12.sp, color = JoniMuted)
            }
          }

          Divider(color = JoniBorder)

          SensorDeviceRow(
            name = "Smartphone 6-Axis IMU",
            status = if (phoneImuActive) "Connected (Internal)" else "Inactive",
            battery = "100%",
            isConnected = phoneImuActive,
            onToggle = { phoneImuActive = !phoneImuActive }
          )

          SensorDeviceRow(
            name = "Left Leg Shank IMU (ESP32-01)",
            status = if (leftConnected) "Connected • Signal Excellent" else "Disconnected",
            battery = "82%",
            isConnected = leftConnected,
            onToggle = { leftConnected = !leftConnected }
          )

          SensorDeviceRow(
            name = "Right Leg Shank IMU (ESP32-02)",
            status = if (rightConnected) "Connected • Signal Good" else "Not Paired / Standby",
            battery = "74%",
            isConnected = rightConnected,
            onToggle = { rightConnected = !rightConnected }
          )

          Button(
            onClick = {
              isScanning = true
              scope.launch {
                delay(1500)
                isScanning = false
                rightConnected = true
              }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = JoniSecondary)
          ) {
            Icon(Icons.Default.Search, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (isScanning) "Scanning BLE Spectrum..." else "Scan & Pair ESP32 Sensor Kit")
          }
        }
      }

      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("Sensor Calibration & Stability Check", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniPrimary)
          Text("Hold device or wearable steady in neutral standing position for baseline accelerometer calibration.", fontSize = 13.sp, color = JoniMuted)

          if (calibrating) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = JoniPrimary)
            Text("Calibrating zero-bias and gravitational vector... Please hold still.", fontSize = 12.sp, color = JoniWarning)
          } else if (calibrationDone) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JoniSuccess)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Calibration Successful • Signal Variance < 0.02g", fontWeight = FontWeight.Bold, color = JoniSuccess, fontSize = 13.sp)
            }
          }

          Button(
            onClick = {
              calibrating = true
              scope.launch {
                delay(2000)
                calibrating = false
                calibrationDone = true
              }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (calibrationDone) JoniSuccess else JoniPrimary)
          ) {
            Text(if (calibrationDone) "Recalibrate Sensors" else "Run Sensor Calibration (5s)")
          }
        }
      }

      Button(
        onClick = { onProceedToMovement(assessmentId) },
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("proceed_to_movement_btn"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
      ) {
        Icon(Icons.Default.ArrowForward, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Proceed to Movement & Pose Capture", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
fun SensorDeviceRow(name: String, status: String, battery: String, isConnected: Boolean, onToggle: () -> Unit) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(JoniBackground, RoundedCornerShape(10.dp))
      .padding(12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
      Icon(
        imageVector = if (isConnected) Icons.Default.Sensors else Icons.Default.SensorsOff,
        contentDescription = null,
        tint = if (isConnected) JoniSuccess else JoniMuted
      )
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JoniText)
        Text("$status • Batt: $battery", fontSize = 11.sp, color = JoniMuted)
      }
    }
    Switch(checked = isConnected, onCheckedChange = { onToggle() })
  }
}
