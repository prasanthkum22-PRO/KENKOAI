package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SensorScreen(
  assessmentId: String,
  onBack: () -> Unit,
  onProceedToAi: () -> Unit
) {
  var isScanning by remember { mutableStateOf(false) }
  var leftImuConnected by remember { mutableStateOf(true) }
  var rightImuConnected by remember { mutableStateOf(false) }
  var calibrating by remember { mutableStateOf(false) }
  var calibrationComplete by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Sensor & IMU Assessment Hub", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.BluetoothConnected, contentDescription = null, tint = JoniPrimary, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text("BLE Low-Cost Sensor Kit", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
              Text("ESP32 6-Axis IMU & Smartphone Accelerometer Fusion", fontSize = 12.sp, color = JoniMuted)
            }
          }

          Divider(color = JoniBorder)

          SensorDeviceItem(
            name = "Smartphone Built-in Accelerometer / Gyro",
            status = "Connected & Calibrated",
            battery = "100%",
            signal = "Excellent",
            connected = true
          )

          SensorDeviceItem(
            name = "Left Shank IMU (ESP32-BLE-01)",
            status = if (leftImuConnected) "Connected" else "Disconnected",
            battery = "84%",
            signal = "Strong (-65 dBm)",
            connected = leftImuConnected
          )

          SensorDeviceItem(
            name = "Right Shank IMU (ESP32-BLE-02)",
            status = if (rightImuConnected) "Connected" else "Pairing Available",
            battery = "78%",
            signal = "Moderate",
            connected = rightImuConnected
          )

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
              onClick = {
                isScanning = true
                scope.launch {
                  delay(1500)
                  rightImuConnected = true
                  isScanning = false
                }
              },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (isScanning) "Scanning..." else "Scan & Pair BLE Kit")
            }

            Button(
              onClick = {
                calibrating = true
                scope.launch {
                  delay(2000)
                  calibrating = false
                  calibrationComplete = true
                }
              },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(10.dp),
              colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary),
              enabled = !calibrating
            ) {
              Text(if (calibrating) "Calibrating..." else "Calibrate Sensors")
            }
          }
        }
      }

      if (calibrationComplete || leftImuConnected) {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSuccess.copy(alpha = 0.1f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = JoniSuccess)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text("Sensor Signal Quality: Excellent", fontWeight = FontWeight.Bold, color = JoniSuccess, fontSize = 14.sp)
              Text("Signal stability ██████████ (98%). Ready for gait & sit-to-stand capture.", fontSize = 12.sp, color = JoniText)
            }
          }
        }
      }

      Button(
        onClick = onProceedToAi,
        modifier = Modifier
          .fillMaxWidth()
          .height(54.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
      ) {
        Icon(Icons.Default.PlayArrow, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Proceed with Sensor & Camera Fusion", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }
    }
  }
}

@Composable
fun SensorDeviceItem(name: String, status: String, battery: String, signal: String, connected: Boolean) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(JoniBackground, RoundedCornerShape(10.dp))
      .padding(12.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = if (connected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
      contentDescription = null,
      tint = if (connected) JoniSuccess else JoniMuted
    )
    Spacer(modifier = Modifier.width(12.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = JoniText)
      Text("Status: $status • Battery: $battery • Signal: $signal", fontSize = 11.sp, color = JoniMuted)
    }
  }
}
