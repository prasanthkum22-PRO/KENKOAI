package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  currentLang: String,
  onToggleLang: () -> Unit,
  onBack: () -> Unit,
  onOpenDiagnostics: () -> Unit,
  onOpenEducation: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Settings & Language", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
          Text("Language & Localization", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniPrimary)

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Interface Language", fontWeight = FontWeight.SemiBold)
            Button(
              onClick = onToggleLang,
              colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary)
            ) {
              Text(if (currentLang == "EN") "Switch to Hindi (हिंदी)" else "Switch to English")
            }
          }
        }
      }

      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("Module Access", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniPrimary)

          OutlinedButton(onClick = onOpenDiagnostics, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Memory, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Hardware & Device Diagnostics")
          }

          OutlinedButton(onClick = onOpenEducation, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.MenuBook, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Patient Education & Joint Health Guide")
          }
        }
      }

      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Privacy & Safety Notice", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
          Text("Kenkoai complies with frontline healthcare data minimization and offline encryption standards. AI screening outputs are experimental and require clinical validation.", fontSize = 13.sp, color = JoniMuted)
        }
      }
    }
  }
}
