package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyncScreen(
  isOnline: Boolean,
  pendingSyncCount: Int,
  onToggleOnline: () -> Unit,
  onSyncNow: () -> Unit,
  onBack: () -> Unit
) {
  var syncing by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Offline Sync Center", fontWeight = FontWeight.Bold) },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = JoniSurface),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("Network & Device Status", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
              Text(if (isOnline) "Connected to Central Server" else "Offline Field Mode", fontSize = 12.sp, color = if (isOnline) JoniSuccess else JoniWarning)
            }
            Switch(checked = isOnline, onCheckedChange = { onToggleOnline() })
          }

          Divider(color = JoniBorder)

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("Pending Local Records", color = JoniMuted, fontSize = 14.sp)
            Text("$pendingSyncCount items", fontWeight = FontWeight.Bold, color = if (pendingSyncCount > 0) JoniWarning else JoniSuccess, fontSize = 14.sp)
          }
        }
      }

      Button(
        onClick = {
          syncing = true
          onSyncNow()
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = JoniPrimary),
        enabled = !syncing && pendingSyncCount > 0
      ) {
        Icon(Icons.Default.Sync, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(if (syncing) "Synchronizing Records..." else "Synchronize Queue Now", fontSize = 16.sp, fontWeight = FontWeight.Bold)
      }

      Text("Local IndexedDB sync queue maintains complete audit trail until network connectivity is restored.", fontSize = 12.sp, color = JoniMuted)
    }
  }
}
