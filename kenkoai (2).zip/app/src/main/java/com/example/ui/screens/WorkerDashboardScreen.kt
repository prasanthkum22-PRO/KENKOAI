package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AssessmentEntity
import com.example.data.PatientEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkerDashboardScreen(
  patients: List<PatientEntity>,
  assessments: List<AssessmentEntity>,
  isOnline: Boolean,
  pendingSyncCount: Int,
  onStartScreening: () -> Unit,
  onRegisterPatient: () -> Unit,
  onOpenPatient: (String) -> Unit,
  onOpenSync: () -> Unit,
  onOpenClinician: () -> Unit,
  onOpenAnalytics: () -> Unit,
  onOpenReports: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenMore: () -> Unit
) {
  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Text("JONI Health Worker", fontWeight = FontWeight.Bold, color = JoniPrimary, fontSize = 18.sp)
            Text("Aizawl Sector • Field Unit 01", fontSize = 12.sp, color = JoniMuted)
          }
        },
        actions = {
          IconButton(onClick = onOpenSync) {
            Badge(containerColor = if (pendingSyncCount > 0) JoniWarning else JoniSuccess) {
              Icon(Icons.Default.Sync, contentDescription = "Sync", tint = JoniText)
            }
          }
          IconButton(onClick = onOpenSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = JoniText)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = JoniSurface)
      )
    },
    bottomBar = {
      NavigationBar(containerColor = JoniSurface) {
        NavigationBarItem(
          icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
          label = { Text("Home") },
          selected = true,
          onClick = {}
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.People, contentDescription = null) },
          label = { Text("Patients") },
          selected = false,
          onClick = onRegisterPatient
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.AddCircle, contentDescription = null, tint = JoniPrimary) },
          label = { Text("Screen", fontWeight = FontWeight.Bold) },
          selected = false,
          onClick = onStartScreening
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.Sync, contentDescription = null) },
          label = { Text("Sync") },
          selected = false,
          onClick = onOpenSync
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.MoreHoriz, contentDescription = null) },
          label = { Text("More") },
          selected = false,
          onClick = onOpenMore
        )
      }
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = onStartScreening,
        containerColor = JoniPrimary,
        contentColor = JoniSurface,
        modifier = Modifier
          .semantics { }
          .testTag("start_screening_fab")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Start Screening")
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .background(JoniBackground)
        .padding(padding)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (isOnline) JoniSuccess.copy(alpha = 0.1f) else JoniWarning.copy(alpha = 0.1f)
          ),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = if (isOnline) Icons.Default.CloudQueue else Icons.Default.CloudOff,
              contentDescription = null,
              tint = if (isOnline) JoniSuccess else JoniWarning
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = if (isOnline) "Online Mode • Connected to Server" else "Offline Mode • Local Storage Active",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = JoniText
              )
              Text(
                text = "$pendingSyncCount assessments in local queue",
                fontSize = 11.sp,
                color = JoniMuted
              )
            }
            TextButton(onClick = onOpenSync) {
              Text("Sync Center", fontWeight = FontWeight.Bold, color = JoniPrimary)
            }
          }
        }
      }

      item {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          MetricCard(title = "Screenings", count = "${assessments.size}", icon = Icons.Default.Assignment, modifier = Modifier.weight(1f))
          MetricCard(title = "Patients", count = "${patients.size}", icon = Icons.Default.Person, modifier = Modifier.weight(1f))
          MetricCard(title = "Pending Sync", count = "$pendingSyncCount", icon = Icons.Default.Sync, modifier = Modifier.weight(1f))
        }
      }

      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = JoniPrimary),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Text("Community Osteoarthritis Screening", color = JoniSurface, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Text("Capture symptoms, mobility limitations, and movement features for AI-assisted screening priority.", color = JoniSurface.copy(alpha = 0.85f), fontSize = 13.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Button(
              onClick = onStartScreening,
              colors = ButtonDefaults.buttonColors(containerColor = JoniSurface),
              shape = RoundedCornerShape(10.dp)
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, tint = JoniPrimary)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Start New Screening", color = JoniPrimary, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      item {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          OutlinedButton(onClick = onRegisterPatient, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
            Icon(Icons.Default.PersonAdd, contentDescription = null, tint = JoniSecondary)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Register Patient", color = JoniText, fontSize = 13.sp)
          }
          OutlinedButton(onClick = onOpenReports, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
            Icon(Icons.Default.Assessment, contentDescription = null, tint = JoniSecondary)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Generate Report", color = JoniText, fontSize = 13.sp)
          }
        }
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Registered Demo Patients", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = JoniText)
          TextButton(onClick = onRegisterPatient) {
            Text("View All", color = JoniPrimary)
          }
        }
      }

      items(patients.take(5)) { patient ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = JoniSurface),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenPatient(patient.id) }
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = JoniSecondary.copy(alpha = 0.1f),
              modifier = Modifier.size(40.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(patient.patientCode.takeLast(3), fontWeight = FontWeight.Bold, color = JoniSecondary, fontSize = 12.sp)
              }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(patient.name, fontWeight = FontWeight.Bold, color = JoniText, fontSize = 15.sp)
              Text("${patient.age} yrs • ${patient.sex} • ${patient.location}", color = JoniMuted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = JoniMuted)
          }
        }
      }
    }
  }
}

@Composable
fun MetricCard(title: String, count: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = JoniSurface),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = JoniPrimary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(title, fontSize = 12.sp, color = JoniMuted)
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(count, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = JoniText)
    }
  }
}
