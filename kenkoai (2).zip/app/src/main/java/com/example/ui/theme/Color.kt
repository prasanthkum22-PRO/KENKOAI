package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val JoniPrimary = Color(0xFF0F766E) // Teal 700
val JoniPrimaryDark = Color(0xFF115E59)
val JoniSecondary = Color(0xFF2563EB) // Blue 600
val JoniBackground = Color(0xFFF6F8FA)
val JoniSurface = Color(0xFFFFFFFF)
val JoniText = Color(0xFF172033)
val JoniMuted = Color(0xFF64748B)
val JoniSuccess = Color(0xFF15803D)
val JoniWarning = Color(0xFFD97706)
val JoniError = Color(0xFFDC2626)
val JoniBorder = Color(0xFFE2E8F0)
