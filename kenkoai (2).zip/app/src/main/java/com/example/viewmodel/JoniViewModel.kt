package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class JoniViewModel(application: Application) : AndroidViewModel(application) {
  private val database = JoniDatabase.getDatabase(application)
  private val repository = JoniRepository(database.joniDao())

  val patients: StateFlow<List<PatientEntity>> = repository.allPatients
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val assessments: StateFlow<List<AssessmentEntity>> = repository.allAssessments
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  val referrals: StateFlow<List<ReferralEntity>> = repository.allReferrals
    .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

  private val _currentUserRole = MutableStateFlow("WORKER") // "WORKER" or "CLINICIAN" or "ADMIN"
  val currentUserRole: StateFlow<String> = _currentUserRole

  private val _currentLanguage = MutableStateFlow("EN") // "EN" or "HI"
  val currentLanguage: StateFlow<String> = _currentLanguage

  private val _isOnline = MutableStateFlow(true)
  val isOnline: StateFlow<Boolean> = _isOnline

  private val _pendingSyncCount = MutableStateFlow(3)
  val pendingSyncCount: StateFlow<Int> = _pendingSyncCount

  fun setRole(role: String) {
    _currentUserRole.value = role
  }

  fun setLanguage(lang: String) {
    _currentLanguage.value = lang
  }

  fun toggleOnlineStatus() {
    _isOnline.value = !_isOnline.value
  }

  fun registerPatient(
    name: String,
    age: Int,
    sex: String,
    location: String,
    occupation: String,
    contact: String,
    consent: Boolean,
    onSuccess: (String) -> Unit
  ) {
    viewModelScope.launch {
      val code = "DEMO-${String.format("%03d", (patients.value.size + 1))}"
      val patient = PatientEntity(
        patientCode = code,
        name = name,
        age = age,
        sex = sex,
        location = location,
        occupation = occupation,
        contact = contact,
        consentStatus = consent
      )
      repository.insertPatient(patient)
      _pendingSyncCount.value += 1
      onSuccess(patient.id)
    }
  }

  suspend fun getPatient(id: String): PatientEntity? {
    return repository.getPatientById(id)
  }

  suspend fun createAssessment(
    patientId: String,
    affectedJoint: String,
    painScore: Int,
    painDuration: String,
    stiffness: String,
    swelling: Boolean,
    mobilityLimitations: String,
    previousInjury: Boolean,
    activityLevel: String
  ): String {
    val assessment = AssessmentEntity(
      patientId = patientId,
      workerId = "HW-Aizawl-01",
      affectedJoint = affectedJoint,
      painScore = painScore,
      painDuration = painDuration,
      stiffness = stiffness,
      swelling = swelling,
      mobilityLimitations = mobilityLimitations,
      previousInjury = previousInjury,
      activityLevel = activityLevel,
      status = "PENDING_REVIEW"
    )
    return repository.insertAssessment(assessment)
  }

  suspend fun saveMovementAndRunAi(
    assessmentId: String,
    taskType: String,
    duration: Int,
    cadence: Float,
    symmetry: Float,
    range: String,
    features: String,
    quality: String
  ): AiResultEntity {
    repository.saveMovement(
      MovementEntity(
        assessmentId = assessmentId,
        taskType = taskType,
        duration = duration,
        cadence = cadence,
        stepSymmetry = symmetry,
        movementRange = range,
        kneeAngleFeatures = features,
        captureQuality = quality
      )
    )

    val assessment = repository.getAssessmentById(assessmentId)
    val pain = assessment?.painScore ?: 5
    val mobility = assessment?.mobilityLimitations ?: ""
    val prevInjury = assessment?.previousInjury ?: false
    val asymmetryScore = 1.0f - symmetry

    return repository.runAiScreening(assessmentId, pain, mobility, prevInjury, asymmetryScore)
  }

  suspend fun getAssessmentDetails(assessmentId: String): Triple<AssessmentEntity?, MovementEntity?, AiResultEntity?> {
    val asm = repository.getAssessmentById(assessmentId)
    val mov = repository.getMovement(assessmentId)
    val ai = repository.getAiResult(assessmentId)
    return Triple(asm, mov, ai)
  }

  suspend fun saveClinicalReview(
    assessmentId: String,
    clinicianId: String,
    note: String,
    recommendation: String
  ) {
    repository.saveClinicalReview(
      ClinicalReviewEntity(
        assessmentId = assessmentId,
        clinicianId = clinicianId,
        status = "REVIEWED",
        clinicalNote = note,
        recommendation = recommendation
      )
    )
    val asm = repository.getAssessmentById(assessmentId)
    if (asm != null) {
      repository.insertReferral(
        ReferralEntity(
          patientId = asm.patientId,
          assessmentId = assessmentId,
          destination = "District Health Hospital Specialist OPD",
          reason = recommendation,
          priority = if (asm.painScore >= 6) "High" else "Routine",
          status = "Active"
        )
      )
    }
  }

  fun syncNow(onComplete: () -> Unit) {
    viewModelScope.launch {
      repository.performSync()
      _pendingSyncCount.value = 0
      onComplete()
    }
  }
}
